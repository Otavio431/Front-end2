// Frontend simples para testar a API
const output = document.getElementById('output');

async function chamarApi(url) {
  output.textContent = 'Carregando...';
  try {
    const res = await fetch(url);
    const data = await res.json();
    output.textContent = JSON.stringify(data, null, 2);
  } catch (err) {
    output.textContent = 'Erro: ' + err.message;
  }
}

document.getElementById('btn-ping').addEventListener('click', () => chamarApi('/api/ping'));
document.getElementById('btn-status').addEventListener('click', () => chamarApi('/api'));
