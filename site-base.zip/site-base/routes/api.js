/**
 * routes/api.js
 * ----------------------------------------------------
 * Sistema simples de API.
 * Adicione novas rotas aqui conforme for criando outros sites.
 * ----------------------------------------------------
 */

const express = require('express');
const router = express.Router();
const firebase = require('../config/firebase');

// GET /api → status da API
router.get('/', (req, res) => {
  res.json({
    ok: true,
    message: 'API rodando',
    firebase: firebase.isReady(),
    timestamp: new Date().toISOString(),
  });
});

// GET /api/ping → teste rápido
router.get('/ping', (req, res) => {
  res.json({ pong: true });
});

// POST /api/echo → devolve o que recebeu (útil para testar)
router.post('/echo', (req, res) => {
  res.json({ recebido: req.body });
});

// ----------- Exemplos com Firebase (Firestore) -----------

// GET /api/items → lista documentos da coleção "items"
router.get('/items', async (req, res) => {
  if (!firebase.isReady()) {
    return res.status(503).json({ error: 'Firebase não configurado' });
  }
  try {
    const snap = await firebase.db().collection('items').get();
    const items = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    res.json(items);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/items → cria um documento na coleção "items"
router.post('/items', async (req, res) => {
  if (!firebase.isReady()) {
    return res.status(503).json({ error: 'Firebase não configurado' });
  }
  try {
    const ref = await firebase.db().collection('items').add({
      ...req.body,
      createdAt: new Date().toISOString(),
    });
    res.status(201).json({ id: ref.id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
