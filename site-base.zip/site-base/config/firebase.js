/**
 * config/firebase.js
 * ----------------------------------------------------
 * Inicialização do Firebase Admin SDK.
 *
 * Há 2 formas de configurar (escolha uma):
 *
 * 1) Usando arquivo serviceAccountKey.json
 *    - Baixe no Firebase Console > Project Settings > Service accounts
 *    - Salve como: config/serviceAccountKey.json
 *
 * 2) Usando variáveis no arquivo .env
 *    FIREBASE_PROJECT_ID=...
 *    FIREBASE_CLIENT_EMAIL=...
 *    FIREBASE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\n....\n-----END PRIVATE KEY-----\n"
 *
 * Se nada estiver configurado, o servidor continua rodando normalmente,
 * apenas sem o Firebase ativo (útil para começar o projeto).
 * ----------------------------------------------------
 */

const admin = require('firebase-admin');
const fs = require('fs');
const path = require('path');

let ready = false;
let db = null;

function inicializar() {
  try {
    const keyPath = path.join(__dirname, 'serviceAccountKey.json');

    // Opção 1: arquivo serviceAccountKey.json
    if (fs.existsSync(keyPath)) {
      const serviceAccount = require(keyPath);
      admin.initializeApp({
        credential: admin.credential.cert(serviceAccount),
      });
      ready = true;
      db = admin.firestore();
      return;
    }

    // Opção 2: variáveis de ambiente
    if (
      process.env.FIREBASE_PROJECT_ID &&
      process.env.FIREBASE_CLIENT_EMAIL &&
      process.env.FIREBASE_PRIVATE_KEY
    ) {
      admin.initializeApp({
        credential: admin.credential.cert({
          projectId: process.env.FIREBASE_PROJECT_ID,
          clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
          privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
        }),
      });
      ready = true;
      db = admin.firestore();
      return;
    }

    console.warn('⚠️   Firebase não configurado. Crie config/serviceAccountKey.json ou preencha o .env');
  } catch (err) {
    console.error('❌  Erro ao inicializar Firebase:', err.message);
  }
}

inicializar();

module.exports = {
  admin,
  db: () => db,
  isReady: () => ready,
};
